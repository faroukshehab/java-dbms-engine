package DBMS;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;



public class DBApp {

    static int dataPageSize = 2;
     static HashMap<String, StringBuilder> traceLogs = new HashMap<>();
     static String Lasttrace;
     

    private static void recordTrace(String tableName, String log) {
        traceLogs.putIfAbsent(tableName, new StringBuilder());
		traceLogs.get(tableName).append(log).append("\n");
		 	
    }

    public static void createTable(String tableName, String[] columnsNames) {
        traceLogs.remove(tableName);
        Table table = new Table(tableName, columnsNames);
        FileManager.storeTable(tableName, table);
        recordTrace(tableName,
            "Table created name:" + tableName
            + ", columnsNames:" + Arrays.toString(columnsNames)
        );

      
        
    }

    public static void insert(String tableName, String[] record) {
        long startTime = System.currentTimeMillis();

        try {
            Table table = FileManager.loadTable(tableName);
            ArrayList<Page> pages = table.getPages();
            boolean inserted = false;

            
            if (pages == null || pages.isEmpty()) {
                Page newPage = new Page(dataPageSize);
                newPage.addRecord(record);
                pages = new ArrayList<>();
                pages.add(newPage);
                table.setPages(pages);
                FileManager.storeTablePage(tableName, 0, newPage);
                long executionTime = System.currentTimeMillis() - startTime;
                recordTrace(tableName,
                        "Inserted:" + Arrays.toString(record)
                                + ", at page number: 0"
                                + ", execution time (mil):" + executionTime);
            } else {
                // Case 2: Scan existing pages to find a non-full one
                for (int i = 0; i < pages.size(); i++) {
                    Page page = FileManager.loadTablePage(tableName, i);
                    if (!page.isfull()) {
                        page.addRecord(record);
                        FileManager.storeTablePage(tableName, i, page);
                        inserted = true;
                        long executionTime = System.currentTimeMillis() - startTime;
                        recordTrace(tableName,
                                "Inserted:" + Arrays.toString(record)
                                        + ", at page number:" + i
                                        + ", execution time (mil):" + executionTime);
                        break;
                    }
                }
                

               
                if (!inserted) {
                    Page newPage = new Page(dataPageSize);
                    newPage.addRecord(record);
                    pages.add(newPage);
                    int newIndex = pages.size() - 1;
                    FileManager.storeTablePage(tableName, newIndex, newPage);
                    long executionTime = System.currentTimeMillis() - startTime;
                    recordTrace(tableName,
                            "Inserted:" + Arrays.toString(record)
                                    + ", at page number:" + newIndex
                                    + ", execution time (mil):" + executionTime);
                }
            }

           
            FileManager.storeTable(tableName, table);

        
            for (String colName : table.getIndexedColumns()) {
                try {
                    BitmapIndex index = FileManager.loadTableIndex(tableName, colName);
                    int colIndex = table.getColumnIndex(colName);
                    String value = record[colIndex];
                    index.insertValue(value); 
                    FileManager.storeTableIndex(tableName, colName, index);
                } catch (Exception e) {
                    System.err.println("Failed to update bitmap index for: " + colName);
                }
            }

        } catch (Exception e) {
            System.out.println("Error inserting into table: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public static ArrayList<String[]> select(String tableName) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        ArrayList<String[]> result = new ArrayList<>();
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            result.addAll(page.getRecords());
        }
        long executionTime = System.currentTimeMillis() - startTime;
        recordTrace(tableName, 
            "Select all pages:" + table.getPages().size() 
            + ", records:" + result.size() 
            + ", execution time (mil):" + executionTime
        );
        return result;
    }

    public static ArrayList<String[]> select(String tableName, int pageNumber, int recordNumber) {
        long startTime = System.currentTimeMillis();
        ArrayList<String[]> results = new ArrayList<>();
        Page page = FileManager.loadTablePage(tableName, pageNumber);
        if (page != null && recordNumber < page.getRecords().size()) {
            String[] record = page.getRecord(recordNumber);
            results.add(record);
        }
        long executionTime = System.currentTimeMillis() - startTime;
        recordTrace(tableName, 
            "Select pointer page:" + pageNumber 
            + ", record:" + recordNumber 
            + ", total output count:" + results.size() 
            + ", execution time (mil):" + executionTime
        );
        return results;
    }

    public static ArrayList<String[]> select(String tableName, String[] cols, String[] vals) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        String[] columnNames = table.getColumnsNames();
        int[] columnIndexes = new int[cols.length];
        for (int i = 0; i < cols.length; i++) {
            for (int j = 0; j < columnNames.length; j++) {
                if (cols[i].equals(columnNames[j])) {
                    columnIndexes[i] = j;
                    break;
                }
            }
        }
        ArrayList<String[]> result = new ArrayList<>();
        ArrayList<String> perPageBreakdown = new ArrayList<>();
        int totalMatches = 0;
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            int matchesThisPage = 0;
            for (int j = 0; j < page.getRecords().size(); j++) {
                String[] record = page.getRecords().get(j);
                boolean match = true;
                for (int k = 0; k < columnIndexes.length; k++) {
                    int colIndex = columnIndexes[k];
                    if (!record[colIndex].equals(vals[k])) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    result.add(record);
                    matchesThisPage++;
                }
            }
            if (matchesThisPage > 0) {
                perPageBreakdown.add("[" + i + ", " + matchesThisPage + "]");
                totalMatches += matchesThisPage;
            }
        }
        long executionTime = System.currentTimeMillis() - startTime;
        recordTrace(tableName, 
            "Select condition:" + Arrays.toString(cols) + "->" + Arrays.toString(vals)
            + ", Records per page:" + perPageBreakdown
            + ", records:" + totalMatches
            + ", execution time (mil):" + executionTime
        );
        return result;
    }
    

    public static String getFullTrace(String tableName) {
        Table table = FileManager.loadTable(tableName);

        if (table == null) {
            return "Table metadata file is missing or corrupted.";
        }

        int totalPages = 0;
        int totalRecords = 0;

        ArrayList<Page> pages = table.getPages();
        if (pages != null) {
            totalPages = pages.size();

            for (int i = 0; i < totalPages; i++) {
                Page page = FileManager.loadTablePage(tableName, i);
                if (page != null) {
                    totalRecords += page.getRecords().size();
                }
            }
        }

        String trace = traceLogs.getOrDefault(tableName, new StringBuilder()).toString();
        return trace +
               "Pages Count: " + totalPages + ", Records Count: " + totalRecords +", Indexed Columns: " + table.getIndexedColumns();
    }

    public static String getLastTrace(String tableName) {
        String fullTrace = traceLogs.getOrDefault(tableName, new StringBuilder()).toString().trim();
        if (fullTrace.isEmpty()) {
            return "No trace available.";
        }
        String[] traces = fullTrace.split("\n");
        if (traces.length == 0) {
            return "No trace available.";
        }
        return traces[traces.length - 1];
    }
  
    private static void enforcePageFilenames(String tableName) {
        Table table = FileManager.loadTable(tableName);
        if (table == null || table.getPages() == null) return;

        File dir = new File("Tables" + File.separator + tableName);
        if (!dir.exists() || !dir.isDirectory()) return;

       
        File[] pageFiles = dir.listFiles((d, name) -> name.matches("\\d+\\.db"));
        if (pageFiles == null) return;

       
        Arrays.sort(pageFiles, Comparator.comparing(File::getName));

        int pageCount = table.getPages().size();
       
        for (int i = 0; i < Math.min(pageFiles.length, pageCount); i++) {
            File curr = pageFiles[i];
            File desired = new File(dir, i + ".db");
            if (!curr.getName().equals(desired.getName())) {
                curr.renameTo(desired);
            }
        }
    }


    private static Set<Integer> getExistingPagesFromTrace(String tableName) {
        String all = FileManager.trace();
        String marker = tableName + "{";
        int idx = all.indexOf(marker);
        if (idx < 0) return Set.of();
        int open = all.indexOf('{', idx);
        int close = all.indexOf('}', open);
        if (open < 0 || close < 0) return Set.of();
        String inside = all.substring(open + 1, close).trim();
        String[] parts = inside.split("\\s+");
        Set<Integer> pages = new HashSet<>();
        for (String p : parts) {
            if (p.matches("\\d+\\.db")) {
                pages.add(Integer.parseInt(p.replace(".db","")));
            }
        }
        return pages;
    }

    
    public static ArrayList<String[]> validateRecords(String tableName) {
        // 1) pull out every "Inserted:[…] at page number:X,…"
        List<String> inserts = new ArrayList<>();
        String full = traceLogs.getOrDefault(tableName, new StringBuilder()).toString();
        for (String line : full.split("\n")) {
            if (line.contains("Inserted:")) inserts.add(line);
        }

       
        Set<Integer> have = getExistingPagesFromTrace(tableName);

       
        ArrayList<String[]> missing = new ArrayList<>();
        for (String ins : inserts) {
            int pi = ins.indexOf("page number:");
            if (pi == -1) continue;
            int comma = ins.indexOf(",", pi);
            int pg = Integer.parseInt(ins.substring(pi + 12, comma).trim());
            if (!have.contains(pg)) {
                int b = ins.indexOf('['), e = ins.indexOf(']');
                if (b != -1 && e != -1) {
                    missing.add(ins.substring(b + 1, e).split(",\\s*"));
                }
            }
        }

        recordTrace(tableName,
          "Validating records: " + missing.size() + " records missing.");
        return missing;
    }

    
    public static void recoverRecords(String tableName, ArrayList<String[]> missing) {
        
        Set<Integer> used = getExistingPagesFromTrace(tableName);
        int recovered = 0;
        List<Integer> pagesCreated = new ArrayList<>();

       
        for (int i = 0; !missing.isEmpty(); i++) {
            if (used.contains(i)) continue;
            Page p = new Page(dataPageSize);
            int cnt = 0;
            while (cnt < dataPageSize && !missing.isEmpty()) {
                p.addRecord(missing.remove(0));
                cnt++;
                recovered++;
            }
            FileManager.storeTablePage(tableName, i, p);
            pagesCreated.add(i);
            used.add(i);
        }

       
        recordTrace(tableName,
          "Recovering " + recovered + " records in pages: " + pagesCreated + ".");
    }
    public static void createBitMapIndex(String tableName, String colName) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        int colIndex = table.getColumnIndex(colName);
        BitmapIndex index = new BitmapIndex();

        ArrayList<Page> pages = table.getPages();
        int c = pages.size();
        for (int i = 0; i < c; i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            for (int j = 0; j < page.getSize(); j++) {
                String[] record = page.getRecord(j);
                String value = record[colIndex];
                index.insertValue(value);
            }
        }

        boolean success = FileManager.storeTableIndex(tableName, colName, index);
        long executionTime = System.currentTimeMillis() - startTime;
        if (!success) {
            System.err.println("Failed to store bitmap index for column: " + colName);
        } else {
            table.addIndex(colName);
            FileManager.storeTable(tableName, table);
            recordTrace(tableName, "Index created for column: " + colName + ", execution time (mil):" + executionTime);
        }
    }
    public static String getValueBits(String tableName, String colName, String value) {
    	 BitmapIndex index = FileManager.loadTableIndex(tableName, colName);

        if (index == null) {
            return "Error: Index not found for column: " + colName;
        }

      
        String bits = index.getBitmap(value);
        return bits;

    }
    public static ArrayList<String[]> selectIndex(String tableName, String[] cols, String[] vals) {
        long startTime = System.currentTimeMillis();

        ArrayList<String[]> result = new ArrayList<>();
        Table table = FileManager.loadTable(tableName);

      
        int numRows = 0;
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            numRows += page.getSize();
        }

        int[] colIndexes = new int[cols.length];
        boolean[] isIndexed = new boolean[cols.length];
        String[][] bitmaps = new String[cols.length][];
        int indexedCount = 0;

       
        for (int i = 0; i < cols.length; i++) {
            colIndexes[i] = table.getColumnIndex(cols[i]);

            if (table.isIndexed(cols[i])) {
                isIndexed[i] = true;
                String bits = getValueBits(tableName, cols[i], vals[i]);
                bitmaps[i] = bits.split("");
                indexedCount++;
            }
        }

       
        boolean[] candidateRows = new boolean[numRows];
        Arrays.fill(candidateRows, true);

        if (indexedCount > 0) {
            for (int i = 0; i < cols.length; i++) {
                if (isIndexed[i]) {
                    for (int j = 0; j < numRows; j++) {
                        candidateRows[j] = candidateRows[j] && bitmaps[i][j].equals("1");
                    }
                }
            }
        }

    
        int currentRow = 0;
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);

            for (int j = 0; j < page.getSize(); j++) {
                String[] record = page.getRecord(j);

                boolean match = (indexedCount == 0) || candidateRows[currentRow];

                if (match) {
                    for (int k = 0; k < cols.length; k++) {
                        if (!isIndexed[k]) {
                            if (!record[colIndexes[k]].equals(vals[k])) {
                                match = false;
                                break;
                            }
                        }
                    }
                }

                if (match) {
                    result.add(record);
                }

                currentRow++;
            }
        }

       
        ArrayList<String> indexedColsList = new ArrayList<>();
        ArrayList<String> nonIndexedColsList = new ArrayList<>();
        for (int i = 0; i < cols.length; i++) {
            if (isIndexed[i]) {
                indexedColsList.add(cols[i]);
            } else {
                nonIndexedColsList.add(cols[i]);
            }
        }

      
        indexedColsList.sort(String::compareTo);
        nonIndexedColsList.sort(String::compareTo);

        int indexedSelectionCount = -1;
        if (indexedCount > 0) {
            indexedSelectionCount = 0;
            for (boolean b : candidateRows) {
                if (b) indexedSelectionCount++;
            }
        }

        long executionTime = System.currentTimeMillis() - startTime;

        StringBuilder trace = new StringBuilder();
        trace.append("Select index condition:").append(Arrays.toString(cols))
             .append("->").append(Arrays.toString(vals));
        if (!indexedColsList.isEmpty()) {
            trace.append(", Indexed columns: ").append(indexedColsList);
            trace.append(", Indexed selection count: ").append(indexedSelectionCount);
        }
        if (!nonIndexedColsList.isEmpty()) {
            trace.append(", Non Indexed: ").append(nonIndexedColsList);
        }
        trace.append(", Final count: ").append(result.size());
        trace.append(", execution time (mil): ").append(executionTime);

        recordTrace(tableName, trace.toString());

        return result;
    }
    public static void main(String []args) throws IOException
    {
    FileManager.reset();
    String[] cols = {"id","name","major","semester","gpa"};
    createTable("student", cols);
    String[] r1 = {"1", "stud1", "CS", "5", "0.9"};
    insert("student", r1);
    String[] r2 = {"2", "stud2", "BI", "7", "1.2"};
    insert("student", r2);
    String[] r3 = {"3", "stud3", "CS", "2", "2.4"};
    insert("student", r3);
    String[] r4 = {"4", "stud4", "CS", "9", "1.2"};
    insert("student", r4);
    String[] r5 = {"5", "stud5", "BI", "4", "3.5"};
    insert("student", r5);

    System.out.println("File Manager trace before deleting pages:"+FileManager.trace());
    String path =FileManager.class.getResource("FileManager.class").toString();File directory = new File(path.substring(6,path.length()-17) +File.separator+ "Tables//student" + File.separator);File[] contents = directory.listFiles();
    int[] pageDel = {1,3};
    for(int i=0;i<pageDel.length;i++)
    {
    contents[pageDel[i]].delete();
    }
   
    System.out.println("File Manager trace after deleting pages:"+FileManager.trace());
    ArrayList<String[]> tr = validateRecords("student");
    System.out.println("Missing records count: "+tr.size());
    recoverRecords("student", tr);
    System.out.println("--------------------------------");
    System.out.println("Recovering the missing records.");
    tr = validateRecords("student");
    System.out.println("Missing record count: "+tr.size());
    System.out.println("File Manager trace after recovering missing records:"+FileManager.trace());
    System.out.println("--------------------------------");
  
    System.out.println(getLastTrace("student"));
    }
    }

