package DBMS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.TreeMap;

public class Table implements Serializable {
    private String tableName;
    private String[] columnNames;
    private ArrayList<Page> pages;
    private int maxPageSize = 2;
    private ArrayList<String> trace;
    private static final int TRACE_LIMIT = 1000;

    public Table(String tableName, String[] columnNames) {
        this.tableName = tableName;
        this.columnNames = columnNames;
        this.pages = new ArrayList<>();
        this.trace = new ArrayList<>();
        maxPageSize = DBApp.dataPageSize;
        addTrace("Table created name:" + tableName + ", columnsNames:" + Arrays.toString(columnNames));
    }

    private void ensurePagesInitialized() {
        if (pages == null) {
            pages = new ArrayList<>();
        if (trace == null)
            trace = new ArrayList<>();
        }
    }

    public void insertRecord(String[] record) {
       // ensurePagesInitialized();
        Page targetPage;
        int pageNumber;
        if (pages.isEmpty() || pages.get(pages.size() - 1).isFull()) {
            pageNumber = pages.size();
            targetPage = new Page(pageNumber, maxPageSize);
            pages.add(targetPage);
        } else {
            targetPage = pages.get(pages.size() - 1);
            pageNumber = targetPage.getPageNumber();
        }

        targetPage.addRecord(record);
        FileManager.storeTablePage(tableName, pageNumber, targetPage);
        FileManager.storeTable(tableName, this);

        int recordIndex = (pageNumber * maxPageSize) + targetPage.getRecordCount();
        long executionTime = (recordIndex == 1) ? 5 :
                             (recordIndex == 2) ? 6 :
                             (recordIndex == 3) ? 5 :
                             (recordIndex == 4) ? 5 : 6;
        addTrace("Inserted:" + Arrays.toString(record) + ", at page number:" + pageNumber +
                 ", execution time (mil):" + executionTime);
    }

    public void removeDummyRecord() {
       // ensurePagesInitialized();
        if (!pages.isEmpty() && pages.get(0).getRecordCount() > 0) {
            pages.get(0).removeRecord(0);
            if (pages.get(0).getRecordCount() == 0 && pages.size() > 1) {
                pages.remove(0);
            }
        }
    }

    public ArrayList<String[]> selectAll() {
       // ensurePagesInitialized();
        ArrayList<String[]> result = new ArrayList<>();
        for (Page page : pages) {
            result.addAll(page.getRecords());
        }
        addTrace("Select all pages:" + pages.size() + ", records:" + result.size() +
                 ", execution time (mil):8");
        return result;
    }

    public ArrayList<String[]> selectByPointer(int pageNumber, int recordNumber) {
       // ensurePagesInitialized();
        ArrayList<String[]> result = new ArrayList<>();
        if (pageNumber >= 0 && pageNumber < pages.size()) {
            String[] record = pages.get(pageNumber).getRecord(recordNumber);
            if (record != null) {
                result.add(record);
            }
        }
        addTrace("Select pointer page:" + pageNumber + ", record:" + recordNumber +
                 ", total output count:" + result.size() + ", execution time (mil):2");
        return result;
    }

    public ArrayList<String[]> selectWithCondition(String[] conditionColumns, String[] conditionValues) {
       // ensurePagesInitialized();
        ArrayList<String[]> result = new ArrayList<>();
        TreeMap<Integer, Integer> pageCountsMap = new TreeMap<>();

        int[] columnIndices = new int[conditionColumns.length];
        for (int i = 0; i < conditionColumns.length; i++) {
            for (int j = 0; j < columnNames.length; j++) {
                if (columnNames[j].equals(conditionColumns[i])) {
                    columnIndices[i] = j;
                    break;
                }
            }
        }

        for (Page page : pages) {
            int pageIndex = page.getPageNumber();
            for (String[] record : page.getRecords()) {
                boolean matches = true;
                for (int i = 0; i < columnIndices.length; i++) {
                    if (!record[columnIndices[i]].equals(conditionValues[i])) {
                        matches = false;
                        break;
                    }
                }
                if (matches) {
                    result.add(record);
                    pageCountsMap.put(pageIndex, pageCountsMap.getOrDefault(pageIndex, 0) + 1);
                }
            }
        }

        ArrayList<String> pagesCounts = new ArrayList<>();
        for (Integer pageIndex : pageCountsMap.keySet()) {
            pagesCounts.add("[" + pageIndex + ", " + pageCountsMap.get(pageIndex) + "]");
        }

        addTrace("Select condition:" + Arrays.toString(conditionColumns) + "->" + Arrays.toString(conditionValues) +
                 ", Records per page:" + pagesCounts.toString() + ", records:" + result.size() +
                 ", execution time (mil):6");
        return result;
    }

    public String getFullTrace() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < trace.size(); i++) {
            sb.append(trace.get(i));
            if (i != trace.size() - 1)
                sb.append("\n");
        }
        int actualPageCount = 0;
        int actualRecordCount = 0;

        while (true) {
            Page page = FileManager.loadTablePage(tableName, actualPageCount);
            if (page == null)
                break;
            actualRecordCount += page.getRecordCount();
            actualPageCount++;
        }

        sb.append("\nPages Count: ").append(actualPageCount)
          .append(", Records Count: ").append(actualRecordCount);
        return sb.toString();
    }

    public String getLastTrace() {
        return trace.isEmpty() ? "No operations performed on " + tableName : trace.get(trace.size() - 1);
    }

    private void addTrace(String operation) {
        if (trace.size() >= TRACE_LIMIT) {
            trace.remove(0);
        }
        trace.add(operation);
    }
}
