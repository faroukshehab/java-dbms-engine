package DBMS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class DBApp {
    private static HashMap<String, Table> tables = new HashMap<>();
    public static int dataPageSize = 2;

    public static void init() throws IOException {
        FileManager.reset();
    }

    public static void createTable(String tableName, String[] columnNames) {
    	tables.remove(tableName);
        Table table = new Table(tableName, columnNames);
        tables.put(tableName, table);
        FileManager.storeTable(tableName, table);
    }

    public static void insert(String tableName, String[] record) {
        tables.get(tableName).insertRecord(record);
    }

    public static ArrayList<String[]> select(String tableName) {
        return tables.get(tableName).selectAll();
    }

    public static ArrayList<String[]> select(String tableName, int pageNumber, int recordNumber) {
        return tables.get(tableName).selectByPointer(pageNumber, recordNumber);
    }

    public static ArrayList<String[]> select(String tableName, String[] conditionColumns, String[] conditionValues) {
        return tables.get(tableName).selectWithCondition(conditionColumns, conditionValues);
    }

    public static String getFullTrace(String tableName) {
        return tables.get(tableName).getFullTrace();
    }

    public static String getLastTrace(String tableName) {
        return tables.get(tableName).getLastTrace();
    }

    public static void main(String[] args) throws IOException {
        init();
        String[] cols = {"id", "name", "major", "semester", "gpa"};
        createTable("student", cols);
        String[] r1 = {"1", "stud1", "CS", "5", "0.9"};
        insert("student", r1);
        String[] r2 = {"2", "stud2", "BI", "7", "1.2"};
        insert("student", r2);
        String[] r3 = {"3", "stud3", "CS", "2", "2.4"};
        insert("student", r3);
        String[] r4 = {"4", "stud4", "DMET", "9", "1.2"};
        insert("student", r4);
        String[] r5 = {"5", "stud5", "BI", "4", "3.5"};
        insert("student", r5);
        System.out.println("Output of selecting the whole table content:");
        ArrayList<String[]> result1 = select("student");
        for (String[] array : result1) {
            for (String str : array) {
                System.out.print(str + " ");
            }
            System.out.println();
        }
        System.out.println("--------------------------------");
        System.out.println("Output of selecting the output by position:");
        ArrayList<String[]> result2 = select("student", 1, 1);
        for (String[] array : result2) {
            for (String str : array) {
                System.out.print(str + " ");
            }
            System.out.println();
        }
        System.out.println("--------------------------------");
        System.out.println("Output of selecting the output by column condition:");
        ArrayList<String[]> result3 = select("student", new String[]{"gpa"}, new String[]{"1.2"});
        for (String[] array : result3) {
            for (String str : array) {
                System.out.print(str + " ");
            }
            System.out.println();
        }
        System.out.println("--------------------------------");
        System.out.println("Full Trace of the table:");
        System.out.println(getFullTrace("student"));
        System.out.println("--------------------------------");
        System.out.println("Last Trace of the table:");
        System.out.println(getLastTrace("student"));
        System.out.println("--------------------------------");
        System.out.println("The trace of the Tables Folder:");
        System.out.println(FileManager.trace());
        FileManager.reset();
        System.out.println("--------------------------------");
        System.out.println("The trace of the Tables Folder after resetting:");
        System.out.println(FileManager.trace());
    }
}