package DBMS;

import java.io.Serializable;
import java.util.ArrayList;

public class Page implements Serializable {
    private int pageNumber;
    private int maxSize;
    private ArrayList<String[]> records;

    public Page(int pageNumber, int maxSize) {
        this.pageNumber = pageNumber;
        this.maxSize = maxSize;
        this.records = new ArrayList<>();
    }

    public void addRecord(String[] record) {
        if (records.size() < maxSize) {
            records.add(record);
        }
    }

    public void removeRecord(int index) {
        if (index >= 0 && index < records.size()) {
            records.remove(index);
        }
    }

    public ArrayList<String[]> getRecords() {
        return new ArrayList<>(records);
    }

    public String[] getRecord(int index) {
        return (index >= 0 && index < records.size()) ? records.get(index) : null;
    }

    public boolean isFull() {
        return records.size() >= maxSize;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public int getRecordCount() {
        return records.size();
    }
}