package DBMS;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class DBApp {

    static int dataPageSize = 2;
     static HashMap<String, StringBuilder> traceLogs = new HashMap<>();
     static String Lasttrace;

    private static void recordTrace(String tableName, String log) {
        traceLogs.putIfAbsent(tableName, new StringBuilder());
		traceLogs.get(tableName).append(log).append("\n");
		 	
    }

    public static void createTable(String tableName, String[] columnsNames) {
    	traceLogs.remove(tableName);
        Table table = new Table(tableName, columnsNames);
        FileManager.storeTable(tableName, table);
        recordTrace(tableName, 
            "Table created name:" + tableName 
             + ", columnsNames:" + Arrays.toString(columnsNames)
        );
    }

    public static void insert(String tableName, String[] record) {
        long startTime = System.currentTimeMillis();

        try {
            Table table = FileManager.loadTable(tableName);
            ArrayList<Page> pages = table.getPages();
            boolean inserted = false;

            // Case 1: No pages exist yet
            if (pages == null || pages.isEmpty()) {
                Page newPage = new Page(dataPageSize);
                newPage.addRecord(record);
                pages = new ArrayList<>();
                pages.add(newPage);
                table.setPages(pages);
                FileManager.storeTablePage(tableName, 0, newPage);
                long executionTime = System.currentTimeMillis() - startTime;
                recordTrace(tableName,
                        "Inserted:" + Arrays.toString(record)
                                + ", at page number: 0"
                                + ", execution time (mil):" + executionTime);
            } else {
                // Case 2: Scan existing pages to find a non-full one
                for (int i = 0; i < pages.size(); i++) {
                    Page page = FileManager.loadTablePage(tableName, i);
                    if (!page.isfull()) {
                        page.addRecord(record);
                        FileManager.storeTablePage(tableName, i, page);
                        inserted = true;
                        long executionTime = System.currentTimeMillis() - startTime;
                        recordTrace(tableName,
                                "Inserted:" + Arrays.toString(record)
                                        + ", at page number:" + i
                                        + ", execution time (mil):" + executionTime);
                        break;
                    }
                }

                // Case 3: All pages are full → add new page
                if (!inserted) {
                    Page newPage = new Page(dataPageSize);
                    newPage.addRecord(record);
                    pages.add(newPage);
                    int newIndex = pages.size() - 1;
                    FileManager.storeTablePage(tableName, newIndex, newPage);
                    long executionTime = System.currentTimeMillis() - startTime;
                    recordTrace(tableName,
                            "Inserted:" + Arrays.toString(record)
                                    + ", at page number:" + newIndex
                                    + ", execution time (mil):" + executionTime);
                }
            }

            // ✅ Save the updated table (with new pages)
            FileManager.storeTable(tableName, table);

            // ✅ Update bitmap indexes for indexed columns
            for (String colName : table.getIndexedColumns()) {
                try {
                    BitmapIndex index = FileManager.loadTableIndex(tableName, colName);
                    int colIndex = table.getColumnIndex(colName);
                    String value = record[colIndex];
                    index.insertValue(value); // Appends 1 to correct bitmap, 0 to others
                    FileManager.storeTableIndex(tableName, colName, index);
                } catch (Exception e) {
                    System.err.println("Failed to update bitmap index for: " + colName);
                }
            }

        } catch (Exception e) {
            System.out.println("Error inserting into table: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public static ArrayList<String[]> select(String tableName) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        ArrayList<String[]> result = new ArrayList<>();
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            result.addAll(page.getRecords());
        }
        long executionTime = System.currentTimeMillis() - startTime;
        recordTrace(tableName, 
            "Select all pages:" + table.getPages().size() 
            + ", records:" + result.size() 
            + ", execution time (mil):" + executionTime
        );
        return result;
    }

    public static ArrayList<String[]> select(String tableName, int pageNumber, int recordNumber) {
        long startTime = System.currentTimeMillis();
        ArrayList<String[]> results = new ArrayList<>();
        Page page = FileManager.loadTablePage(tableName, pageNumber);
        if (page != null && recordNumber < page.getRecords().size()) {
            String[] record = page.getRecord(recordNumber);
            results.add(record);
        }
        long executionTime = System.currentTimeMillis() - startTime;
        recordTrace(tableName, 
            "Select pointer page:" + pageNumber 
            + ", record:" + recordNumber 
            + ", total output count:" + results.size() 
            + ", execution time (mil):" + executionTime
        );
        return results;
    }

    public static ArrayList<String[]> select(String tableName, String[] cols, String[] vals) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        String[] columnNames = table.getColumnsNames();
        int[] columnIndexes = new int[cols.length];
        for (int i = 0; i < cols.length; i++) {
            for (int j = 0; j < columnNames.length; j++) {
                if (cols[i].equals(columnNames[j])) {
                    columnIndexes[i] = j;
                    break;
                }
            }
        }
        ArrayList<String[]> result = new ArrayList<>();
        ArrayList<String> perPageBreakdown = new ArrayList<>();
        int totalMatches = 0;
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            int matchesThisPage = 0;
            for (int j = 0; j < page.getRecords().size(); j++) {
                String[] record = page.getRecords().get(j);
                boolean match = true;
                for (int k = 0; k < columnIndexes.length; k++) {
                    int colIndex = columnIndexes[k];
                    if (!record[colIndex].equals(vals[k])) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    result.add(record);
                    matchesThisPage++;
                }
            }
            if (matchesThisPage > 0) {
                perPageBreakdown.add("[" + i + ", " + matchesThisPage + "]");
                totalMatches += matchesThisPage;
            }
        }
        long executionTime = System.currentTimeMillis() - startTime;
        recordTrace(tableName, 
            "Select condition:" + Arrays.toString(cols) + "->" + Arrays.toString(vals)
            + ", Records per page:" + perPageBreakdown
            + ", records:" + totalMatches
            + ", execution time (mil):" + executionTime
        );
        return result;
    }
    private static ArrayList<String> getSortedDbFileNames(File dir) {
        ArrayList<String> fileNames = new ArrayList<>();
        String[] rawNames = dir.list();
        if (rawNames == null) return fileNames;

        for (String name : rawNames) {
            if (name.matches("\\d+\\.db")) {
                fileNames.add(name);
            }
        }

        fileNames.sort(String::compareTo); // Lexicographic sort
        return fileNames;
    }

    public static String getFullTrace(String tableName) {
        Table table = FileManager.loadTable(tableName);

        if (table == null) {
            return "Table metadata file is missing or corrupted.";
        }

        int totalPages = 0;
        int totalRecords = 0;

        ArrayList<Page> pages = table.getPages();
        if (pages != null) {
            totalPages = pages.size();

            for (int i = 0; i < totalPages; i++) {
                Page page = FileManager.loadTablePage(tableName, i);
                if (page != null) {
                    totalRecords += page.getRecords().size();
                }
            }
        }

        String trace = traceLogs.getOrDefault(tableName, new StringBuilder()).toString();
        return trace +
               "Pages Count: " + totalPages + ", Records Count: " + totalRecords +", Indexed Columns: " + table.getIndexedColumns();
    }

    public static String getLastTrace(String tableName) {
        String fullTrace = traceLogs.getOrDefault(tableName, new StringBuilder()).toString().trim();
        if (fullTrace.isEmpty()) {
            return "No trace available.";
        }
        String[] traces = fullTrace.split("\n");
        if (traces.length == 0) {
            return "No trace available.";
        }
        return traces[traces.length - 1];
    }
  

    public static ArrayList<String[]> validateRecords(String tableName) {
        ArrayList<String[]> missingRecords = new ArrayList<>();

        // Load table metadata
        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            System.err.println("Table metadata file is missing or corrupted.");
            return missingRecords;
        }

        ArrayList<Page> pages = table.getPages();
        if (pages == null || pages.isEmpty()) {
            return missingRecords;
        }

        // Check which page files exist
        File tableDir = new File("Tables" + File.separator + tableName);
        if (!tableDir.exists() || !tableDir.isDirectory()) {
            System.err.println("Table folder does not exist: " + tableName);
            return missingRecords;
        }

        HashSet<String> existingFiles = new HashSet<>();
        String[] files = tableDir.list();
        if (files != null) {
            existingFiles.addAll(Arrays.asList(files));
        }

        for (int i = 0; i < pages.size(); i++) {
            String pageFileName = i + ".db";
            if (!existingFiles.contains(pageFileName)) {
                Page ghostPage = pages.get(i);
                if (ghostPage != null) {
                    missingRecords.addAll(ghostPage.getRecords());
                }
            }
        }

        return missingRecords;
    }

    public static void recoverRecords(String tableName, ArrayList<String[]> missing) {
        long startTime = System.currentTimeMillis();

        if (missing == null || missing.isEmpty()) {
            recordTrace(tableName, "No records to recover.");
            return;
        }

        Table table = FileManager.loadTable(tableName);
        if (table == null) {
            recordTrace(tableName, "Cannot recover: table metadata missing.");
            return;
        }

        ArrayList<Page> pages = table.getPages();
        int recoveredPages = 0;

        for (int i = 0; i < pages.size(); i++) {
            Page page = pages.get(i);
            boolean hasMissing = false;

            for (int j = 0; j < page.getSize(); j++) {
                String[] record = page.getRecord(j);
                for (int k = 0; k < missing.size(); k++) {
                    if (Arrays.equals(record, missing.get(k))) {
                        hasMissing = true;
                        break;
                    }
                }
                if (hasMissing) break;
            }

            if (hasMissing) {
                FileManager.storeTablePage(tableName, i, page);
                recoveredPages++;
            }
        }

        FileManager.storeTable(tableName, table);

        long executionTime = System.currentTimeMillis() - startTime;
        recordTrace(tableName,
            "Recovered pages: " + recoveredPages +
            ", missing records: " + missing.size() +
            ", execution time (mil): " + executionTime
        );
    }

    public static void createBitMapIndex(String tableName, String colName) {
        long startTime = System.currentTimeMillis();
        Table table = FileManager.loadTable(tableName);
        int colIndex = table.getColumnIndex(colName);
        BitmapIndex index = new BitmapIndex();

        ArrayList<Page> pages = table.getPages();
        int c = pages.size();
        for (int i = 0; i < c; i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            for (int j = 0; j < page.getSize(); j++) {
                String[] record = page.getRecord(j);
                String value = record[colIndex];
                index.insertValue(value);
            }
        }

        boolean success = FileManager.storeTableIndex(tableName, colName, index);
        long executionTime = System.currentTimeMillis() - startTime;
        if (!success) {
            System.err.println("Failed to store bitmap index for column: " + colName);
        } else {
            table.addIndex(colName);
            FileManager.storeTable(tableName, table);
            recordTrace(tableName, "Index created for column: " + colName + ", execution time (mil):" + executionTime);
        }
    }
    public static String getValueBits(String tableName, String colName, String value) {
    	 BitmapIndex index = FileManager.loadTableIndex(tableName, colName);

        if (index == null) {
            return "Error: Index not found for column: " + colName;
        }

        // Get the bitstream for the given value
        String bits = index.getBitmap(value);
        return bits;

    }
    public static ArrayList<String[]> selectIndex(String tableName, String[] cols, String[] vals) {
        long startTime = System.currentTimeMillis();

        ArrayList<String[]> result = new ArrayList<>();
        Table table = FileManager.loadTable(tableName);

        // Step 1: Count total rows
        int numRows = 0;
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);
            numRows += page.getSize();
        }

        int[] colIndexes = new int[cols.length];
        boolean[] isIndexed = new boolean[cols.length];
        String[][] bitmaps = new String[cols.length][];
        int indexedCount = 0;

        // Step 2: Check index presence and retrieve bitmaps
        for (int i = 0; i < cols.length; i++) {
            colIndexes[i] = table.getColumnIndex(cols[i]);

            if (table.isIndexed(cols[i])) {
                isIndexed[i] = true;
                String bits = getValueBits(tableName, cols[i], vals[i]);
                bitmaps[i] = bits.split("");
                indexedCount++;
            }
        }

        // Step 3: Initialize candidate row set
        boolean[] candidateRows = new boolean[numRows];
        Arrays.fill(candidateRows, true);

        if (indexedCount > 0) {
            for (int i = 0; i < cols.length; i++) {
                if (isIndexed[i]) {
                    for (int j = 0; j < numRows; j++) {
                        candidateRows[j] = candidateRows[j] && bitmaps[i][j].equals("1");
                    }
                }
            }
        }

        // Step 4: Apply any remaining linear conditions
        int currentRow = 0;
        for (int i = 0; i < table.getPages().size(); i++) {
            Page page = FileManager.loadTablePage(tableName, i);

            for (int j = 0; j < page.getSize(); j++) {
                String[] record = page.getRecord(j);

                boolean match = (indexedCount == 0) || candidateRows[currentRow];

                if (match) {
                    for (int k = 0; k < cols.length; k++) {
                        if (!isIndexed[k]) {
                            if (!record[colIndexes[k]].equals(vals[k])) {
                                match = false;
                                break;
                            }
                        }
                    }
                }

                if (match) {
                    result.add(record);
                }

                currentRow++;
            }
        }

        // Step 5: Build trace
        ArrayList<String> indexedColsList = new ArrayList<>();
        ArrayList<String> nonIndexedColsList = new ArrayList<>();
        for (int i = 0; i < cols.length; i++) {
            if (isIndexed[i]) {
                indexedColsList.add(cols[i]);
            } else {
                nonIndexedColsList.add(cols[i]);
            }
        }

        int indexedSelectionCount = -1;
        if (indexedCount > 0) {
            indexedSelectionCount = 0;
            for (boolean b : candidateRows) {
                if (b) indexedSelectionCount++;
            }
        }

        long executionTime = System.currentTimeMillis() - startTime;

        StringBuilder trace = new StringBuilder();
        trace.append("Select index condition:").append(Arrays.toString(cols))
             .append("->").append(Arrays.toString(vals));
        if (!indexedColsList.isEmpty()) {
            trace.append(", Indexed columns: ").append(indexedColsList);
            trace.append(", Indexed selection count: ").append(indexedSelectionCount);
        }
        if (!nonIndexedColsList.isEmpty()) {
            trace.append(", Non Indexed: ").append(nonIndexedColsList);
        }
        trace.append(", Final count: ").append(result.size());
        trace.append(", execution time (mil): ").append(executionTime);

        recordTrace(tableName, trace.toString());

        return result;
    }

    public static void main(String []args) throws IOException
    {
    FileManager.reset();
    String[] cols = {"id","name","major","semester","gpa"};
    createTable("student", cols);
    String[] r1 = {"1", "stud1", "CS", "5", "0.9"};
    insert("student", r1);
    String[] r2 = {"2", "stud2", "BI", "7", "1.2"};
    insert("student", r2);
    String[] r3 = {"3", "stud3", "CS", "2", "2.4"};
    insert("student", r3);
    String[] r4 = {"4", "stud4", "CS", "9", "1.2"};
    insert("student", r4);
    String[] r5 = {"5", "stud5", "BI", "4", "3.5"};
    insert("student", r5);
    
    System.out.println("File Manager trace before deleting pages:"+FileManager.trace());
    String path =FileManager.class.getResource("FileManager.class").toString();File directory = new File(path.substring(6,path.length()-17) +File.separator+ "Tables//student" + File.separator);File[] contents = directory.listFiles();
    int[] pageDel = {0,2};
    for(int i=0;i<pageDel.length;i++)
    {
    contents[pageDel[i]].delete();
    }
    ////////End of deleting pages code
    System.out.println("File Manager trace after deleting pages:"+FileManager.trace());
    ArrayList<String[]> tr = validateRecords("student");
    System.out.println("Missing records count: "+tr.size());
    recoverRecords("student", tr);
    System.out.println("--------------------------------");
    System.out.println("Recovering the missing records.");
    tr = validateRecords("student");
    System.out.println("Missing record count: "+tr.size());
    System.out.println("File Manager trace after recovering missing records:"+FileManager.trace());
    System.out.println("--------------------------------");
    System.out.println("Full trace of the table: ");
    System.out.println(getFullTrace("student"));
    }
}