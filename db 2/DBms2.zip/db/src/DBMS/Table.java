package DBMS;



import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Table implements Serializable {

    private String tableName;
    private String[] columnsNames;
    private ArrayList<Page> pages;
    private ArrayList<String> indexedColumns = new ArrayList<>(); // ✅ NEW: Track indexed columns
    HashMap<String, StringBuilder> traceLogs = new HashMap<>();

    public Table(String tableName, String[] columnsNames) {
        this.tableName = tableName;
        this.columnsNames = columnsNames;
        this.pages = new ArrayList<>();
    }

    public void setPages(ArrayList<Page> pages) {
        this.pages = pages;
    }

    public String getTableName() {
        return tableName;
    }

    public String[] getColumnsNames() {
        return columnsNames;
    }

    public ArrayList<Page> getPages() {
        return pages;
    }

    public void addPage(Page page) {
        pages.add(page);
    }

    public Page getPage(int index) {
        return pages.get(index);
    }

    public int getColumnIndex(String colName) {
        for (int i = 0; i < columnsNames.length; i++) {
            if (columnsNames[i].equals(colName)) {
                return i;
            }
        }
        throw new RuntimeException("Column not found: " + colName);
    }

    // ✅ NEW: Add an indexed column
    public void addIndex(String colName) {
        if (!indexedColumns.contains(colName)) {
            indexedColumns.add(colName);
        }
    }

    // ✅ NEW: Check if a column is indexed
    public boolean isIndexed(String colName) {
        return indexedColumns.contains(colName);
    }

    // ✅ Optional: Get all indexed columns
    public ArrayList<String> getIndexedColumns() {
        return indexedColumns;
    }
}
	

