package DBMS;

import java.io.Serializable;
import java.util.*;

public class BitmapIndex implements Serializable {
    private static final long serialVersionUID = 1L;
    private int rowCount = 0; 

    // Map each value in the column to its corresponding bit vector (as a list of 0s and 1s)
    private Map<String, ArrayList<Integer>> index;

    public BitmapIndex() {
        index = new HashMap<>();
    }

    // Adds a new value for a new row (used during insertion)
    public void insertValue(String value) {
        rowCount++; // ✅ increment row count BEFORE inserting

        // Update all existing bitmaps
        for (ArrayList<Integer> bitmap : index.values()) {
            bitmap.add(0); // pad with 0 for this new row
        }

        // Handle the target value
        if (index.containsKey(value)) {
            index.get(value).set(rowCount - 1, 1); // set last bit to 1
        } else {
            ArrayList<Integer> newBitmap = new ArrayList<>(Collections.nCopies(rowCount, 0));
            newBitmap.set(rowCount - 1, 1);
            index.put(value, newBitmap);
        }
    }

    // Gets the size of bitmaps (number of rows)
    public int getSize() {
        // Pick any existing bitmap to get size
        if (!index.isEmpty()) {
            return index.values().iterator().next().size();
        }
        return 0;
    }

    // Returns bitmap for a specific value as a binary string (e.g., "10110")
    public String getBitmap(String value) {
        ArrayList<Integer> bitmap = index.get(value);
        if (bitmap == null) return "0".repeat(getSize()); // all 0s if value never inserted
        StringBuilder sb = new StringBuilder();
        for (int bit : bitmap) {
            sb.append(bit);
        }
        return sb.toString();
    }

    // Debug or display the full index
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String value : index.keySet()) {
            sb.append(value).append(" -> ").append(getBitmap(value)).append("\n");
        }
        return sb.toString();
    }

    // Optional: Get values and their bitmaps (used in selectIndex logic)
    public Map<String, ArrayList<Integer>> getIndexMap() {
        return index;
    }
}